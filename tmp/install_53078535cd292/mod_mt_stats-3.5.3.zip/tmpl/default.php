<?php defined('_JEXEC') or die('Restricted access'); ?>
<center><?php 
	echo JText::sprintf('MOD_MT_STATS_TEXT', $total_links, $total_categories); 
?></center>