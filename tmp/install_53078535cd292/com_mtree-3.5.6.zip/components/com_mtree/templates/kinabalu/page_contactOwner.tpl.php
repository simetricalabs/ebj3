<h2 class="contentheading"><?php echo JText::sprintf( 'COM_MTREE_LISTING_CONTACT_OWNER_TITLE', $this->link->link_name ); ?></h2>

<div id="listing">
	<?php include $this->loadTemplate( 'sub_contactOwnerForm.tpl.php' ); ?>
</div>