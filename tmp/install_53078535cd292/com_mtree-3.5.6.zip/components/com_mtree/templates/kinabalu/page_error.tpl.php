 
<h2 class="contentheading"><?php echo JText::_( 'COM_MTREE_ERROR' ) ?></h2>

<p /><center><strong><?php echo $this->error_msg ?></strong></center>