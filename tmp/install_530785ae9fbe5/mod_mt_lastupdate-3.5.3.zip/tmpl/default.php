<?php defined('_JEXEC') or die('Restricted access'); ?>
<center><?php echo JText::sprintf($caption, $last_update); ?></center>